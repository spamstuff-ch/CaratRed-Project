﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaratRedUI
{
    public partial class ConfirmationSearchCTRL : UserControl
    {

        private static ConfirmationSearchCTRL _instance;

        public static ConfirmationSearchCTRL Instance => _instance ?? (_instance = new ConfirmationSearchCTRL());

        public EventHandler OnSearchClick { get; set; }

        public ConfirmationSearchCTRL()
        {
            InitializeComponent();
        }

        private void ConfirmationSearchCTRL_Load(object sender, EventArgs e)
        {

        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            if (OnSearchClick != null)
            {
                OnSearchClick(this, new EventArgs());
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (OnSearchClick != null)
            {
                OnSearchClick(this, new EventArgs());
            }
        }
    }
}
