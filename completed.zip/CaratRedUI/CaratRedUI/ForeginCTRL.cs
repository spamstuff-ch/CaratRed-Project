﻿using CaratRedFi_800RLibrary;
using FiScnUtildN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaratRedUI
{
    public partial class ForeginCTRL : UserControl
    {
        ScannerConnection sc;
        Bitmap bitmap;
        bool Flag = false;

        private static ForeginCTRL _instance;
        public EventHandler BackToDashBoard1 { get; set; }
        public static ForeginCTRL Instance => _instance ?? (_instance = new ForeginCTRL());
        public ForeginCTRL()
        {
            Flag = false;
            InitializeComponent();
            sc = new ScannerConnection();
            sc.axFiScn1.ScanToRawEx += axFiScn1_ScanToRawEx;
            sc.axFiScn1.CreateControl();
        }

        private void ForeginCTRL_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Flag = true;
            pictureBox1.Image = null;
            sc.ForeignId(Handle.ToInt32());
            //SplitImage(bitmap);


            Form2 form2 = new Form2(bitmap);
            form2.ShowDialog();
            pictureBox1.Image = form2.SelectedImage;
            button5.Visible = false;
        }

        private void ForeginCTRL_Load_1(object sender, EventArgs e)
        {

        }

        private void axFiScn1_ScanToRawEx(object sender, AxFiScnLib._DFiScnEvents_ScanToRawExEvent e)
        {
            ConvH2BM Conv = new ConvH2BM();
            bitmap = Conv.GetBitmapFromRAW(e.resolution, e.imageWidth, e.imageLength, e.bitPerPixel, e.compressionType, e.size, e.raw);

            if (Flag == false)
            {
                if (pictureBox1.Image == null)
                {
                    pictureBox1.Image = bitmap;
                }
                else
                {
                    pictureBox2.Image = bitmap;
                }
            }
        }
        private void SplitImage(Bitmap bmp)
        {
            Bitmap image = bmp;
            Rectangle rect = new Rectangle(0, 0, image.Width, image.Height/2);
            Bitmap firstHalf = image.Clone(rect, image.PixelFormat);
            pictureBox1.Image = firstHalf;
            rect = new Rectangle(0, image.Height / 2, image.Width, image.Height/2);
            Bitmap secondHalf = image.Clone(rect, image.PixelFormat);
            pictureBox2.Image = secondHalf;
            Flag = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Flag = true;
            pictureBox4.Image = null;
            sc.ForeignId(Handle.ToInt32());
            //SplitImage(bitmap);

            Form2 form2 = new Form2(bitmap);
            form2.ShowDialog();
            pictureBox4.Image = form2.SelectedImage;
            button6.Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            pictureBox4.Image=null;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Bitmap piture = (Bitmap)pictureBox1.Image;
            System.IO.MemoryStream ms = new MemoryStream();
            piture.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            byte[] byteImage = ms.ToArray();
            var SigBase64 = Convert.ToBase64String(byteImage);
            textBox1.Text = SigBase64;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (BackToDashBoard1 != null)
            {
                BackToDashBoard1(this, new EventArgs());
            }
        }
    }
}
