﻿namespace CaratRedUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RootPannel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // RootPannel
            // 
            this.RootPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RootPannel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.RootPannel.Location = new System.Drawing.Point(0, 0);
            this.RootPannel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.RootPannel.Name = "RootPannel";
            this.RootPannel.Size = new System.Drawing.Size(1064, 681);
            this.RootPannel.TabIndex = 0;
            this.RootPannel.Paint += new System.Windows.Forms.PaintEventHandler(this.RootPannel_Paint);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1064, 681);
            this.Controls.Add(this.RootPannel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel RootPannel;
    }
}

