﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaratRedUI
{
    public partial class IndianPassportCTRL : UserControl
    {
        private static IndianPassportCTRL _instance;
        public EventHandler BackToDashBoard2 { get; set; }
        public static IndianPassportCTRL Instance => _instance ?? (_instance = new IndianPassportCTRL());
        public IndianPassportCTRL()
        {
            InitializeComponent();
        }

        private void IndianPassportCTRL_Load(object sender, EventArgs e)
        {

        }

        private void IndianPassportCTRL_Load_1(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (BackToDashBoard2 != null)
            {
                BackToDashBoard2(this, new EventArgs());
            }
        }
    }
}
