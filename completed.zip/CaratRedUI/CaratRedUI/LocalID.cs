﻿using CaratRedFi_800RLibrary;
using FiScnUtildN;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaratRedUI
{
    public partial class LocalID : UserControl
    {
        ScannerConnection sc;
        Bitmap bitmap;
        bool Flag = false;
        private static LocalID _instance;
        public EventHandler BackToDashBoard { get; set; }
        public static LocalID Instance => _instance ?? (_instance = new LocalID());
        public LocalID()
        {
            Flag = false;
            InitializeComponent();
            sc = new ScannerConnection();
            sc.axFiScn1.ScanToRawEx += axFiScn1_ScanToRawEx;
            sc.axFiScn1.CreateControl();
        }
        private void button5_Click(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void LocalID_Load(object sender, EventArgs e)
        {

        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (BackToDashBoard != null)
            {
                BackToDashBoard(this, new EventArgs());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            sc.LocalId(Handle.ToInt32());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
            pictureBox2.Image = null;
            sc.LocalId(Handle.ToInt32());
        }

        private void axFiScn1_ScanToRawEx(object sender, AxFiScnLib._DFiScnEvents_ScanToRawExEvent e)
        {
            ConvH2BM Conv = new ConvH2BM();
            bitmap = Conv.GetBitmapFromRAW(e.resolution, e.imageWidth, e.imageLength, e.bitPerPixel, e.compressionType, e.size, e.raw);

            if (Flag == false)
            {
                if (pictureBox2.Image == null)
                {
                    pictureBox2.Image = bitmap;
                    button1.Visible = false;
                }
                else
                {
                    pictureBox3.Image = bitmap;
                    button6.Visible = false;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = null;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            pictureBox3.Image = null;
        }
    }
}
